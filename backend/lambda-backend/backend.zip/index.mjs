// index.mjs — FINAL FULL VERSION
// Google Login + DynamoDB + TMDB Proxy
// Updated to use itemId (matches backend.yaml)

import AWS from "aws-sdk";
import fetch from "node-fetch";
import { OAuth2Client } from "google-auth-library";

const TABLE_NAME = process.env.TABLE_NAME;            // "MovieWatchlist"
const RATINGS_TABLE = process.env.RATINGS_TABLE_NAME; // "MovieRatings"
const TMDB_KEY = process.env.TMDB_KEY;
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;

const ddb = new AWS.DynamoDB.DocumentClient();
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);

// ---------------------------------------------------------
// Helper: Standard JSON response
// ---------------------------------------------------------
function res(status, body) {
  return {
    statusCode: status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Methods": "*",
    },
    body: JSON.stringify(body),
  };
}

// ---------------------------------------------------------
// Google Token Verification
// ---------------------------------------------------------
async function verifyGoogleToken(idToken) {
  try {
    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: GOOGLE_CLIENT_ID,
    });
    return ticket.getPayload();
  } catch (err) {
    console.error("Google token verification failed:", err);
    return null;
  }
}

// ---------------------------------------------------------
// MAIN HANDLER
// ---------------------------------------------------------
export const handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));

  const method = event.requestContext?.http?.method;
  const path = event.rawPath;
  const qs = event.queryStringParameters || {};

  // ---------------------------
  // AUTH HEADER
  // ---------------------------
  const idToken =
    event.headers["x-google-id-token"] ||
    event.headers["X-Google-ID-Token"];

  if (!idToken) {
    return res(400, { ok: false, error: "Missing Google ID token" });
  }

  const payload = await verifyGoogleToken(idToken);
  if (!payload) {
    return res(401, { ok: false, error: "Invalid Google token" });
  }

  const userId = payload.sub;
  console.log("Authenticated user:", userId);

  // =======================================================
  // ROUTING
  // =======================================================

  // -------------------------------------------------------
  // TMDB PROXY: GET /tmdb?endpoint=...
  // -------------------------------------------------------
  if (method === "GET" && path === "/tmdb") {
    const endpoint = qs.endpoint;
    if (!endpoint) {
      return res(400, { ok: false, error: "Missing endpoint" });
    }

    const url = `https://api.themoviedb.org/3/${endpoint}${
      endpoint.includes("?") ? "&" : "?"
    }api_key=${TMDB_KEY}`;

    try {
      const tmdbRes = await fetch(url);
      const json = await tmdbRes.json();

      return res(200, { ok: true, data: json });
    } catch (err) {
      console.error("TMDB error:", err);
      return res(500, { ok: false, error: "TMDB fetch failed" });
    }
  }

  // -------------------------------------------------------
  // GET WATCHLIST: GET /watchlist
  // -------------------------------------------------------
  if (method === "GET" && path === "/watchlist") {
    try {
      const result = await ddb
        .query({
          TableName: TABLE_NAME,
          KeyConditionExpression: "userId = :uid",
          ExpressionAttributeValues: { ":uid": userId },
        })
        .promise();

      return res(200, { ok: true, items: result.Items || [] });
    } catch (err) {
      console.error("Watchlist GET error:", err);
      return res(500, { ok: false, error: "Failed to load watchlist" });
    }
  }

  // -------------------------------------------------------
  // ADD/UPDATE WATCHLIST ITEM: POST /watchlist
  // -------------------------------------------------------
  if (method === "POST" && path === "/watchlist") {
    let body;
    try {
      body = JSON.parse(event.body);
    } catch {
      return res(400, { ok: false, error: "Invalid JSON body" });
    }

    if (!body.itemId) {
      return res(400, { ok: false, error: "itemId is required" });
    }

    const item = {
      userId,
      itemId: body.itemId,
      title: body.title,
      media_type: body.media_type,
      rating: body.rating,
      updatedAt: new Date().toISOString(),
      ...body,
    };

    try {
      await ddb
        .put({
          TableName: TABLE_NAME,
          Item: item,
        })
        .promise();

      return res(200, { ok: true, item });
    } catch (err) {
      console.error("Put error:", err);
      return res(500, { ok: false, error: "Failed to save item" });
    }
  }

  // -------------------------------------------------------
  // DELETE WATCHLIST ITEM: DELETE /watchlist/{itemId}
  // -------------------------------------------------------
  if (method === "DELETE" && path.startsWith("/watchlist/")) {
    const itemId = decodeURIComponent(path.split("/")[2]);

    try {
      await ddb
        .delete({
          TableName: TABLE_NAME,
          Key: { userId, itemId },
        })
        .promise();

      return res(200, { ok: true, deleted: itemId });
    } catch (err) {
      console.error("Delete error:", err);
      return res(500, { ok: false, error: "Failed to delete item" });
    }
  }

  // -------------------------------------------------------
  // FALLBACK
  // -------------------------------------------------------
  return res(404, {
    ok: false,
    error: "Route not found",
    path,
    method,
  });
};
