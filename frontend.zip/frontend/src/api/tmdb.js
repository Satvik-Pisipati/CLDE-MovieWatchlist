const BACKEND_URL = import.meta.env.VITE_BACKEND_URL;

/**
 * Build auth headers with Google ID token (if present).
 */
function buildHeaders() {
  let token = null;
  try {
    token = localStorage.getItem("google_id_token");
  } catch {
    token = null;
  }

  const headers = {
    "Content-Type": "application/json",
  };

  if (token) {
    headers["X-Google-ID-Token"] = token;
  }

  return headers;
}

/**
 * Generic TMDB proxy call via backend.
 * `endpoint` is a TMDB path like:
 *   "search/multi?query=..."
 *   "trending/all/week?language=de-DE"
 *   "movie/123?language=de-DE"
 *   "tv/456?language=de-DE"
 */
export async function fetchTMDB(endpoint) {
  const url = `${BACKEND_URL}/tmdb?endpoint=${encodeURIComponent(endpoint)}`;

  const res = await fetch(url, {
    method: "GET",
    headers: buildHeaders(),
  });

  if (!res.ok) {
    console.error("TMDB proxy fetch failed:", res.status, url);
    throw new Error(`TMDB proxy error: ${res.status}`);
  }

  return await res.json();
}

/* -------------------------------------------------------
   Search across movies & TV
------------------------------------------------------- */
export async function searchTMDB(query, language = "de-DE") {
  if (!query) return [];
  const data = await fetchTMDB(
    `search/multi?query=${encodeURIComponent(query)}&language=${language}`
  );
  return (
    data.results?.filter(
      (item) => item.media_type === "movie" || item.media_type === "tv"
    ) || []
  );
}

/* -------------------------------------------------------
   Get trending movies/TV
------------------------------------------------------- */
export async function trendingTMDB(language = "de-DE", timeWindow = "week") {
  const data = await fetchTMDB(
    `trending/all/${timeWindow}?language=${language}`
  );
  return data.results || [];
}

/* -------------------------------------------------------
   Get detailed info for a movie or TV show
------------------------------------------------------- */
export async function getDetails(media_type, id, language = "de-DE") {
  if (!media_type || !id) return null;
  const data = await fetchTMDB(`${media_type}/${id}?language=${language}`);
  return data;
}

/* -------------------------------------------------------
   Get recommendations for a given media item
------------------------------------------------------- */
export async function getRecommendations(
  media_type,
  id,
  language = "de-DE"
) {
  if (!media_type || !id) return [];
  const data = await fetchTMDB(
    `${media_type}/${id}/recommendations?language=${language}`
  );
  return data.results || [];
}

/* -------------------------------------------------------
   Build recommendations from user watchlist
   (aggregates recs for each saved item)
------------------------------------------------------- */
export async function recommendationsFromWatchlist(list, language = "de-DE") {
  if (!Array.isArray(list) || list.length === 0) return [];

  const all = [];
  for (const item of list) {
    try {
      const recs = await getRecommendations(
        item.media_type,
        item.id,
        language
      );
      all.push(...recs);
    } catch (err) {
      console.warn("Recommendation fetch failed:", err);
    }
  }

  // De-duplicate by TMDB ID
  const unique = [];
  const seen = new Set();
  for (const r of all) {
    const key = `${r.media_type}-${r.id}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(r);
    }
  }
  return unique;
}

/* -------------------------------------------------------
   Get merged list of genres (Movies + TV)
------------------------------------------------------- */
export async function getGenres(language = "de-DE") {
  const [movieGenres, tvGenres] = await Promise.all([
    fetchTMDB(`genre/movie/list?language=${language}`),
    fetchTMDB(`genre/tv/list?language=${language}`),
  ]);

  // Merge and deduplicate by ID (TMDB reuses many)
  const byId = new Map();
  (movieGenres.genres || []).forEach((g) => byId.set(g.id, g));
  (tvGenres.genres || []).forEach((g) => byId.set(g.id, g));

  return Array.from(byId.values()).sort((a, b) => a.name.localeCompare(b.name));
}

/* -------------------------------------------------------
   Utility: Build full TMDB poster URL
   (Images CAN be loaded directly from TMDB.)
------------------------------------------------------- */
export function posterUrl(path, size = "w500") {
  if (!path) return "https://via.placeholder.com/500x750?text=No+Image";
  return `https://image.tmdb.org/t/p/${size}${path}`;
}
