import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { jwtDecode } from "jwt-decode";

const AuthContext = createContext(null);

const TOKEN_STORAGE_KEY = "google_id_token";
const USER_STORAGE_KEY = "google_user";

export function AuthProvider({ children }) {
  const [googleIdToken, setGoogleIdToken] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  // Restore auth state from localStorage on load
  useEffect(() => {
    try {
      const storedToken = localStorage.getItem(TOKEN_STORAGE_KEY);
      const storedUser = localStorage.getItem(USER_STORAGE_KEY);
      if (storedToken) {
        setGoogleIdToken(storedToken);
        if (storedUser) {
          setCurrentUser(JSON.parse(storedUser));
        } else {
          setCurrentUser(jwtDecode(storedToken));
        }
      }
    } catch (err) {
      console.error("Failed to restore auth session", err);
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      localStorage.removeItem(USER_STORAGE_KEY);
    }
  }, []);

  // Persist token
  useEffect(() => {
    if (googleIdToken) {
      localStorage.setItem(TOKEN_STORAGE_KEY, googleIdToken);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  }, [googleIdToken]);

  // Persist user
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(USER_STORAGE_KEY);
    }
  }, [currentUser]);

  const login = (decodedUser, idToken) => {
    try {
      const token = idToken;
      const user = decodedUser ?? (token ? jwtDecode(token) : null);
      if (!token || !user) throw new Error("Invalid Google credential");
      setGoogleIdToken(token);
      setCurrentUser(user);
    } catch (err) {
      console.error("Failed to log in with Google", err);
      throw err;
    }
  };

  const logout = () => {
    setGoogleIdToken(null);
    setCurrentUser(null);
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    localStorage.removeItem(USER_STORAGE_KEY);
    if (typeof window !== "undefined") {
      window.location.replace("/login");
    }
  };

  const value = useMemo(
    () => ({
      currentUser,
      googleIdToken,
      isAuthenticated: Boolean(googleIdToken),
      login,
      logout,
    }),
    [currentUser, googleIdToken]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return ctx;
}
