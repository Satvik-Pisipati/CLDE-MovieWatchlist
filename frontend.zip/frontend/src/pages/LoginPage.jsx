// frontend/src/pages/LoginPage.jsx

import { GoogleLogin } from "@react-oauth/google";
import { useAuth } from "../state/AuthContext";
import { useLocation, useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const searchParams = new URLSearchParams(location.search);
  const redirectTo = searchParams.get("redirectTo") || "/";

  const handleSuccess = (credentialResponse) => {
    const token = credentialResponse?.credential;
    if (!token) {
      console.error("No credential received from Google");
      return;
    }

    try {
      // Decode Google payload
      const decoded = jwtDecode(token);

      console.log("Google Login success:", decoded);

      // 🔥 CRITICAL FIX:
      // Store the token BEFORE redirecting, so TMDB fetches get the header
      localStorage.setItem("google_id_token", token);
      localStorage.setItem("google_user", JSON.stringify(decoded));

      // Update global auth state
      login(decoded, token);

      // Redirect AFTER token is persisted
      navigate(redirectTo, { replace: true });

    } catch (err) {
      console.error("Failed to handle Google credential", err);
    }
  };

  const handleError = () => {
    console.error("Google Login Failed");
  };

  return (
    <div className="flex flex-col items-center justify-center h-full py-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-6">Login</h1>

        <p className="mb-6 text-gray-100">
          Please log in with your Google account to continue.
        </p>

        <GoogleLogin onSuccess={handleSuccess} onError={handleError} />
      </div>
    </div>
  );
}
